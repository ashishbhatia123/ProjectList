insert into employee values(101,'brajesh');
