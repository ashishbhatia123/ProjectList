package com.capgemini.Capstore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.model.Product;



@Controller
public class URIController {
	
	
	

	@PersistenceContext
	EntityManager em;


	@RequestMapping("/")
	public  String home(ModelMap map) {
		
		
		
		Query query=em.createQuery("select distinct p.prodCategory from Product p");
	
		List<String> categoryList=query.getResultList();
		System.out.println(categoryList);
		
		List<Product> productList = new ArrayList<>();
		
		Map<String,List<Product>> categoryMap = new HashMap<>();
		//Map<String,List<String>> urlMap=new HashMap<>();
		
		for(String prodCategory:categoryList) 
		{
			query=em.createQuery("select p from Product p where p.prodCategory=:cat").setParameter("cat",prodCategory);
			
			
			productList=query.getResultList();
			for(Product product:productList) 
			{
				Query query1=em.createNativeQuery(" select url from images where image_id=(select image_id from prod_images where prod_id='"+product.getProdId()+"')");
				List<String> urlList=query1.getResultList();
				System.out.println(urlList);
			//	System.out.println();
				//urlMap.put(product.getProd_id(), urlList);
				
				
			}
			
			
			
			categoryMap.put(prodCategory, productList);
			
			
		}
		//map.addAttribute("urlmap",urlMap);
		map.addAttribute("map",categoryMap);
		
		
		
		 return "/views/index.jsp";
	}
	@RequestMapping("/getCategory")
	public  String categoryProduct(@RequestParam("category")String prodCategory, Model model) {
		Query query;
		
		Map<String,List<Product>> categoryMap = new HashMap<>();
		query=em.createQuery("select p from Product p where p.prodCategory=:cat").setParameter("cat",prodCategory);
		
		
		List<Product> productList=query.getResultList();
		categoryMap.put(prodCategory, productList);
		model.addAttribute("map", categoryMap);
		return "/views/index.jsp";
		
		
	}
	

	@RequestMapping(value="/getProduct")
	public ModelAndView getProductPage(@RequestParam("id") String productId ) {
	
		Product product=em.find(Product.class,productId);
		
		return new ModelAndView("/views/product.jsp","product",product);
	}
	
	
	/*
	@RequestMapping("/index")
	public  String index() {
		
		return "/views/index.jsp";
		
		
	}

	@RequestMapping("/getLogin")
	public  String login() {
		
		return "/views/login.jsp";
		
		
	}
	
	@RequestMapping("/registerAsCustomer")
	public  String registerCustomer() {
		
		return "/views/registerCustomer.jsp";
		
		
	}
	
	
	@RequestMapping("/getContact")
	public  String contact() {
		
		return "/views/contact.jsp";
		
		
	}
	
	
	
	@RequestMapping(value="/getProduct/{productId}")
	public ModelAndView getProductPage(@PathVariable int productId ) {
		System.out.println("consoler"+productId);
		
		RestTemplate restTemplate = new RestTemplate();
		Product displayProduct = restTemplate.getForObject("http://localhost:8099/product.json",Product.class);
		return new ModelAndView("/views/product.jsp","product",displayProduct);
	}
	
	@RequestMapping(value="/getCheckout")
	public String getCheckoutPage() {
		
		return "/views/checkout.jsp";
	}
	
*/	}
