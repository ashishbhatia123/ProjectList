package com.capgemini.managingCart.beans;

public enum MerchantType
{
	NORMAL,THIRD_PARTY;
}
