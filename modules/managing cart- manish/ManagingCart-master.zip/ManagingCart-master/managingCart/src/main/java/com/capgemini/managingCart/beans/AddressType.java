package com.capgemini.managingCart.beans;

public enum AddressType 
{
	HOME,WORK
}
