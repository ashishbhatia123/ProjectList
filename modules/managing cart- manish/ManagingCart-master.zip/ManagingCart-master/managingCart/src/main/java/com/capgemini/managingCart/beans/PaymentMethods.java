package com.capgemini.managingCart.beans;

public enum PaymentMethods 
{
	CASH_ON_DELIVERY , NETBANKING , CARD;
}
